﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectBLab
{
    class RubricsClass
    {
        private int id;
        private string Details;
        private string cloname;


        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Details1
        {
            get
            {
                return Details;
            }

            set
            {
                Details = value;
            }
        }

        public string Cloname
        {
            get
            {
                return cloname;
            }

            set
            {
                cloname = value;
            }
        }

        public void ADD_Rubric(string detail, string Cloname)
           {
                MessageBox.Show("i am in rubics");
                string query ="select Id FROM Clo where Name = '" + Cloname + "'";
                Connection C1 = new Connection();
                int id = C1.get_Id_clo(query);
            MessageBox.Show("id get from clo is " + id);
              if(id >= 0)
              {
                string Insertquery = "Insert into Rubric (Details, CloId) VALUES('" + detail + "','" + id + "')";
                MessageBox.Show("inthe class of Rubics");
                C1.Insertion(Insertquery);
              }
           }
           public void RubricRecord()
           {
               string query = "SELECT * FROM Rubric";
               Connection C1 = new Connection();
               C1.RubricRecord(query);

           }
           public void Delete(int id)
           {
               string query = "Delete FROM Rubric where Id = " + id;
               Connection C1 = new Connection();
               C1.Deletion(query);
           }
          public void Edit(int id, string detail,string name)
           {
            string myquery = "select Id FROM Clo where Name = '" + name + "'";
            Connection C2 = new Connection();
               int idclo = C2.get_Id_clo(myquery);
               string query = "UPDATE Rubric SET  Details = '" + detail + "', Id = '" + idclo + "'where Id = " + id;
               Connection C1 = new Connection();
               C1.UPdate(query);
           } 


    }
}
