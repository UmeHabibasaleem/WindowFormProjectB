﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectBLab
{
    public partial class Rubrics : Form
    {
        string CLO;
        int globalindex;
        public Rubrics()
        {
            InitializeComponent();
        }

        private void Rubrics_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectBDataSet1.Clo' table. You can move, or remove it, as needed.
            this.cloTableAdapter1.Fill(this.projectBDataSet1.Clo);
            // TODO: This line of code loads data into the 'projectBDataSet.Clo' table. You can move, or remove it, as needed.
            // this.cloTableAdapter.Fill(this.projectBDataSet.Clo);
            RubricsClass Rub = new RubricsClass();
            ListofClasses lt1 = new ListofClasses();
            Rub.RubricRecord();
            RubricsDetail.DataSource = lt1.RubList;

        }

        

        private void Add_Click(object sender, EventArgs e)
        {
            RubricsClass rub = new RubricsClass();
            if(Details.Text == " ")
            {
                MessageBox.Show("please fill the detail box first");
                Details_TextChanged(sender, e);
            }
            else
            {
                string clo = Closelection.GetItemText(Closelection.SelectedItem);
                MessageBox.Show("i am in add click" + clo);
                rub.ADD_Rubric(Details.Text, clo);
            }
            
        }

        private void Details_TextChanged(object sender, EventArgs e)
       {

        }

        private void RubricsDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            RubricsClass Rub = new RubricsClass();
            ListofClasses lt = new ListofClasses();
            int index = RubricsDetail.CurrentCell.RowIndex;
            DataGridViewRow r = RubricsDetail.Rows[index];
            int id = Convert.ToInt32(r.Cells[0].Value);
            if (RubricsDetail.Columns[e.ColumnIndex].Name == "Delete")
            {
                DialogResult result = MessageBox.Show("Do You Want to delete?" + id, "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    Rub.Delete(id);
                    MessageBox.Show("id of the selested row is" + id);
                }
                else
                {
                    return;
                }
            }
           if (RubricsDetail.Columns[e.ColumnIndex].Name == "Edit")
            {
                Closelection.SelectedIndex = -1;
                Details.Text = r.Cells[2].Value.ToString();
                CLO = r.Cells[1].Value.ToString();
                Closelection.SelectedText = CLO;
                globalindex = id;
            } 
        }

        private void Save_Click(object sender, EventArgs e)
        {
            RubricsClass Rub = new RubricsClass();
           /* if(Closelection.SelectedItem != null)
           {
               if (Closelection.SelectedItem.ToString() != CLO)
                {
                    MessageBox.Show("You cant change the Clo");
                    Closelection.SelectedIndex = -1;
                    Closelection.SelectedText = CLO;
                }
            } */
           
            Rub.Edit(globalindex,Details.Text,CLO);
            Details.Text = " ";
            Closelection.SelectedText = " ";
           
        }

        private void Closelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
