﻿namespace ProjectBLab
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.Attendene = new System.Windows.Forms.LinkLabel();
            this.AssComManage = new System.Windows.Forms.LinkLabel();
            this.ASSMAnagement = new System.Windows.Forms.LinkLabel();
            this.StuResultManagement = new System.Windows.Forms.LinkLabel();
            this.StuManagement = new System.Windows.Forms.LinkLabel();
            this.CloManagement = new System.Windows.Forms.LinkLabel();
            this.RubManagement = new System.Windows.Forms.LinkLabel();
            this.RLManagement = new System.Windows.Forms.LinkLabel();
            this.GenerateCloReport = new System.Windows.Forms.Button();
            this.StudentAttendence = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.AssessmentReport = new System.Windows.Forms.Button();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.AssessmentReport, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.Attendene, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.AssComManage, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ASSMAnagement, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.StuResultManagement, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.StuManagement, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.CloManagement, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.RubManagement, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.RLManagement, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.GenerateCloReport, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.StudentAttendence, 0, 8);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(347, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 11;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(337, 524);
            this.tableLayoutPanel2.TabIndex = 1;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // Attendene
            // 
            this.Attendene.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Attendene.AutoSize = true;
            this.Attendene.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Attendene.LinkColor = System.Drawing.Color.MidnightBlue;
            this.Attendene.Location = new System.Drawing.Point(89, 156);
            this.Attendene.Name = "Attendene";
            this.Attendene.Size = new System.Drawing.Size(158, 16);
            this.Attendene.TabIndex = 7;
            this.Attendene.TabStop = true;
            this.Attendene.Text = "Attendence Management";
            this.Attendene.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Attendene_LinkClicked);
            // 
            // AssComManage
            // 
            this.AssComManage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AssComManage.AutoSize = true;
            this.AssComManage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssComManage.LinkColor = System.Drawing.Color.MidnightBlue;
            this.AssComManage.Location = new System.Drawing.Point(50, 109);
            this.AssComManage.Name = "AssComManage";
            this.AssComManage.Size = new System.Drawing.Size(236, 16);
            this.AssComManage.TabIndex = 5;
            this.AssComManage.TabStop = true;
            this.AssComManage.Text = "Assessment Component Management";
            this.AssComManage.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.AssComManage_LinkClicked);
            // 
            // ASSMAnagement
            // 
            this.ASSMAnagement.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ASSMAnagement.AutoSize = true;
            this.ASSMAnagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ASSMAnagement.LinkColor = System.Drawing.Color.MidnightBlue;
            this.ASSMAnagement.Location = new System.Drawing.Point(86, 62);
            this.ASSMAnagement.Name = "ASSMAnagement";
            this.ASSMAnagement.Size = new System.Drawing.Size(164, 16);
            this.ASSMAnagement.TabIndex = 3;
            this.ASSMAnagement.TabStop = true;
            this.ASSMAnagement.Text = "Assessment Management";
            this.ASSMAnagement.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ASSMAnagement_LinkClicked);
            // 
            // StuResultManagement
            // 
            this.StuResultManagement.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.StuResultManagement.AutoSize = true;
            this.StuResultManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StuResultManagement.LinkColor = System.Drawing.Color.MidnightBlue;
            this.StuResultManagement.Location = new System.Drawing.Point(77, 15);
            this.StuResultManagement.Name = "StuResultManagement";
            this.StuResultManagement.Size = new System.Drawing.Size(182, 16);
            this.StuResultManagement.TabIndex = 1;
            this.StuResultManagement.TabStop = true;
            this.StuResultManagement.Text = "Student  Result  Management";
            this.StuResultManagement.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.StuResultManagement_LinkClicked);
            // 
            // StuManagement
            // 
            this.StuManagement.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.StuManagement.AutoSize = true;
            this.StuManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StuManagement.LinkColor = System.Drawing.Color.MidnightBlue;
            this.StuManagement.Location = new System.Drawing.Point(101, 203);
            this.StuManagement.Name = "StuManagement";
            this.StuManagement.Size = new System.Drawing.Size(135, 16);
            this.StuManagement.TabIndex = 0;
            this.StuManagement.TabStop = true;
            this.StuManagement.Text = "Student Management";
            this.StuManagement.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.StuManagement_LinkClicked);
            // 
            // CloManagement
            // 
            this.CloManagement.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CloManagement.AutoSize = true;
            this.CloManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloManagement.LinkColor = System.Drawing.Color.MidnightBlue;
            this.CloManagement.Location = new System.Drawing.Point(113, 250);
            this.CloManagement.Name = "CloManagement";
            this.CloManagement.Size = new System.Drawing.Size(110, 16);
            this.CloManagement.TabIndex = 2;
            this.CloManagement.TabStop = true;
            this.CloManagement.Text = "Clo Management";
            this.CloManagement.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CloManagement_LinkClicked);
            // 
            // RubManagement
            // 
            this.RubManagement.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RubManagement.AutoSize = true;
            this.RubManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RubManagement.LinkColor = System.Drawing.Color.MidnightBlue;
            this.RubManagement.Location = new System.Drawing.Point(104, 297);
            this.RubManagement.Name = "RubManagement";
            this.RubManagement.Size = new System.Drawing.Size(129, 16);
            this.RubManagement.TabIndex = 4;
            this.RubManagement.TabStop = true;
            this.RubManagement.Text = "Rubric Management";
            this.RubManagement.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.RubManagement_LinkClicked);
            // 
            // RLManagement
            // 
            this.RLManagement.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RLManagement.AutoSize = true;
            this.RLManagement.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RLManagement.LinkColor = System.Drawing.Color.MidnightBlue;
            this.RLManagement.Location = new System.Drawing.Point(86, 344);
            this.RLManagement.Name = "RLManagement";
            this.RLManagement.Size = new System.Drawing.Size(165, 16);
            this.RLManagement.TabIndex = 6;
            this.RLManagement.TabStop = true;
            this.RLManagement.Text = "Rubric Level Management";
            this.RLManagement.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.RLManagement_LinkClicked);
            // 
            // GenerateCloReport
            // 
            this.GenerateCloReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GenerateCloReport.BackColor = System.Drawing.Color.MidnightBlue;
            this.GenerateCloReport.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GenerateCloReport.Location = new System.Drawing.Point(48, 426);
            this.GenerateCloReport.Name = "GenerateCloReport";
            this.GenerateCloReport.Size = new System.Drawing.Size(241, 41);
            this.GenerateCloReport.TabIndex = 9;
            this.GenerateCloReport.Text = "Generate Report CLO";
            this.GenerateCloReport.UseVisualStyleBackColor = false;
            this.GenerateCloReport.Click += new System.EventHandler(this.GenerateCloReport_Click);
            // 
            // StudentAttendence
            // 
            this.StudentAttendence.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.StudentAttendence.AutoSize = true;
            this.StudentAttendence.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentAttendence.LinkColor = System.Drawing.Color.MidnightBlue;
            this.StudentAttendence.Location = new System.Drawing.Point(65, 391);
            this.StudentAttendence.Name = "StudentAttendence";
            this.StudentAttendence.Size = new System.Drawing.Size(206, 16);
            this.StudentAttendence.TabIndex = 8;
            this.StudentAttendence.TabStop = true;
            this.StudentAttendence.Text = "Student Attendence Management";
            this.StudentAttendence.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.StudentAttendence_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SkyBlue;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(350, 524);
            this.panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(44, 62);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(227, 180);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // AssessmentReport
            // 
            this.AssessmentReport.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AssessmentReport.BackColor = System.Drawing.Color.MidnightBlue;
            this.AssessmentReport.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AssessmentReport.Location = new System.Drawing.Point(48, 476);
            this.AssessmentReport.Name = "AssessmentReport";
            this.AssessmentReport.Size = new System.Drawing.Size(241, 41);
            this.AssessmentReport.TabIndex = 10;
            this.AssessmentReport.Text = "Generate Report Assessment";
            this.AssessmentReport.UseVisualStyleBackColor = false;
            this.AssessmentReport.Click += new System.EventHandler(this.AssessmentReport_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 524);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "Home";
            this.Text = "Home";
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.LinkLabel Attendene;
        private System.Windows.Forms.LinkLabel RLManagement;
        private System.Windows.Forms.LinkLabel AssComManage;
        private System.Windows.Forms.LinkLabel RubManagement;
        private System.Windows.Forms.LinkLabel ASSMAnagement;
        private System.Windows.Forms.LinkLabel CloManagement;
        private System.Windows.Forms.LinkLabel StuResultManagement;
        private System.Windows.Forms.LinkLabel StuManagement;
        private System.Windows.Forms.LinkLabel StudentAttendence;
        private System.Windows.Forms.Button GenerateCloReport;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button AssessmentReport;
    }
}